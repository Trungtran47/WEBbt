<?php
$server = $_SERVER['Server_Name'];
$username = "root";
$password = "";
$db = "udn";
$conn = mysqli_connect($server, $username, $password, $db);
mysqli_query($conn,"set name 'utf8'");
?>